/*
	* this sw will RELOAD if 1 byte is changed
	there is an issue about how to deal with the caching of pages when developing during the day
	if about:debugging  stop sw?
	how do we turn it off?  the sw is flagged to the browser by a link to the MANIFEST.json
	this link is created dynamically by /index.js which is called in /index.php
	****  the sw is REGISTERED in index.js, so I could comment out during the day, then uncomment at COP  *****
  //************************************change something here to reregister 
 
  	other filtering methods to try
  	Request.destination  document image audio video style script manifest font 
  	Request.mode
  	Request.pathname.includes("-ep.php") //rtns t or f
  	Request.pathname.match(/strToFind/)  //rtns t or f

  	example of .destination read only property of the Request
    switch(event.request.destination) {
      case "document":

      break;
      case "video":
        //use network, don't cache
        break;
      case "audio":
        //use network don't cache
        break;
      case "document":
        //cache first, then network
        break;
      default:
        //network first then cache
    } //end switch

*/
const staticCache = 'brainbox-pwa-v3.0'; //use versioning to delete cache when upgrading, dev
const dynamicCache = "brainbox-dynamic-v3.0";
//cashe some static UI pages and styling, and key js
const staticCacheFiles = [
  '/',
  //'/index.php',
  '/favicon.png',
  '/images/box-114.png',

  //'/apps.php', //not during dev
  '/apps/appliances/index.php',
  '/apps/assistive/index.php',
  '/apps/audio/index.php',
  '/apps/banking/index.php',
  '/apps/bookBox/index.php',
  '/apps/bookmarks/index.php',
  '/apps/calendar/index.php',
  '/apps/doorbell/index.php',
  '/apps/electric/index.php',
  '/apps/gamebox/index.php',
  '/apps/gas/index.php',
  '/apps/gogglebox/index.php',
  '/apps/graphics/index.php',
  '/apps/groceries/index.php',
  '/apps/growbox/index.php',
  '/apps/health/index.php',
  '/apps/heatingOil/index.php',
  '/apps/homebooks/index.php',
  '/apps/homeCare/index.php',
  '/apps/homeLock/index.php',
  '/apps/homeVideos/index.php',
  '/apps/house/index.php',
  '/apps/inBox/index.php',
  '/apps/inventory/index.php',
  '/apps/investments/index.php',
  '/apps/isp/index.php',
  '/apps/lightbox/index.php',
  '/apps/lists/index.php',
  '/apps/lunchbox/index.php',
  '/apps/meters/index.php',
  '/apps/movies/index.php',
  '/apps/news/index.php',
  '/apps/notes/index.php',
  '/apps/office/index.php',
  '/apps/passwords/index.php',
  '/apps/people/index.php',
  '/apps/pets/index.php',
  '/apps/phoneBox/index.php',
  '/apps/photos/index.php',
  '/apps/postbox/index.php',
  '/apps/properties/index.php',
  '/apps/research/index.php',

  '/apps/radio/index.php',
  '/apps/savings/index.php',
  '/apps/soapbox/index.php',
  '/apps/squeezebox/index.php',
  '/apps/timers/index.php',
  '/apps/toybox/index.php',
  '/apps/vehicles/index.php',
  '/apps/warmbox/index.php',
  '/apps/water/index.php',
  '/apps/weather/index.php',
  '/apps/websiteMaker/index.php',
  '/apps/zoom/index.php',


  '/apps/index.php',
  '/backup/index.php',
  '/sharing/index.php',
  '/users/index.php',
  '/tweak/index.php',
  '/helpLanding.php',
  //'/lib/css/hs/homeServer.css',  reinstate these when dev slows down otherwise I am going to scream
  //'/lib/css/hs/navbar.css',
  '/lib/css/font-awesome.min.css',
  //'/lib/js/hs/index.js',
  //'/lib/js/hs/homeServer.js',
  //'/lib/js/hs/navbar.js',
  '/lib/js/nicEdit.js',
  '/offline.php',  
  '/images/boob.jpg'
 
];

/* INSTALL EVENT */
/* this should only install for a second time, if the sw code has changed */
self.addEventListener( 'install', e => {
  console.info('Install event, SW installing');
  e.waitUntil(
    caches.open(staticCache)
    .then( brian =>  {
      console.info('Install event, SW caches being added');
      return brian.addAll( staticCacheFiles );
    })
  );
});

//ACTIVATE EVENT
self.addEventListener('activate', e => {
  console.info('Activate event, SW being activated', e);
  
  e.waitUntil(
    caches.keys()
    .then( keys  => {
      return Promise.all( 
        keys
        .filter( key => key !== staticCache ) // && key !== dynamicCache
        .map( key => caches.delete(key))  //delete something ,Iknow not what... I think this is deleting this may be cache control using versions...
        )
    })
  );
  
});

//FETCH EVENT FIXME handle UI with data fetches that fail when offline (the browser caches data 
//fetches as JSON when online and displays when offline, but what do we do when this fails because 
//data wasn't cached when online?)
self.addEventListener('fetch', e => {
  //response to static files, Cache-first
  e.respondWith(
    caches.match( e.request ) //check if the request has already been cached
    .then( cacheRes => {
      //console.info("service worker is checking cache for this url... ", cacheRes );

      //Request ={
      //body: (...), 
      //bodyUsed: true, 
      //headers: Headers {}, 
      //ok: true, 
      //redirected: false, 
      //status: 200, 
      //statusText: "",
      //type: "basic",
      //url: "https://newton.house/index.php
        
        return cacheRes || fetch( e.request ).then( async function (fetchRes) {

            if(  e.request.url.includes("/git/")
              || e.request.url.includes('/auth/') //nb consider adding /users/
              || e.request.url.includes("/tweak/")
              || e.request.url.includes("/logs/")
              || e.request.url.includes("/cgi/")
              || e.request.url.includes("/working/")
              || e.request.url.includes("ep.php")
              || e.request.url.includes("/NLQProcessing")
              || e.request.url.includes("/signOut")
              || e.request.url.includes("/signIn")
              || e.request.url.includes("/manifest")
              || e.request.url.includes("/apps.php")
              || e.request.url.includes("/hdd/")
              || e.request.status != 200
              ) 
            {
              console.info("DO NOT CACHE request for this url ", e.request.url );
              //return fetch results but do not add to cache
              return fetchRes;
            }
            //add all other pages to dynamic cache
		        const thomas = await caches.open(dynamicCache);
		        thomas.put(e.request.url, fetchRes.clone()); //have to clone, else we cant return it
            return fetchRes;     			
            
            //FIXME -- don't cache redirected or non-200 responses, the code below doesn't work
            //do not cache the redirected sign in page (ie requsted url content == sign in html! )
            if( e.request.redirected == true ) {
              console.info("DO NOT CACHE this url, you have been redirected to another page");
              //return the fetch result but do not cache
            	//return fetchRes;
            }
            //do not cache request errors
            if( e.request.status != 200 ) {
              console.info("DO NOT CACHE this url, you got a request error code, not 200 ", e.request.status );
              //return the fetch result but do not cache
            	//return fetchRes;
            }

          })
        .catch( () => { 
          return caches.match('/offline.php') 
        }); //catch will rtn "TypeError: Failed to fetch"
    })
    .catch( () => {
      //only serve offline page if UI page requested this is our BOOB page
      return caches.match('/offline.php');
    })
  ); 

});


