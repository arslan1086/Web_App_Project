<?php
  //the js handling for click events and modal container are in navBar.php and navbar.js
?>
     <footer>
        <!-- rich text editor -->
        <script src="/lib/js/nicEdit.js"></script>
  	   <div> 
          Suggestion Box ... How could we improve this page? 
          <button id="improve-page-btn" class="arrowNavElement" >Tell us</button>
        </div>

     </footer>
   <!-- end whole page container id=grid-wrapper-->
   </div>
</body>
</html>


