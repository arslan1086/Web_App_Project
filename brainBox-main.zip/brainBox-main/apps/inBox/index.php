<?php 

include $_SERVER['DOCUMENT_ROOT'] . "/header.php";
include $_SERVER["DOCUMENT_ROOT"] . "/htmlHeader.php";
include $_SERVER['DOCUMENT_ROOT'] . "/navBar.php";

?>

<section class="landing" >

	<div class="titleHeader">
	  <i class="fa fa-paper-plane"></i> Emails
	</div>

	<div class="nav-boxes">
	  <div class="nav-box"> <a href="emailApp.php"><h3>Emails</h3><i class="fa fa-paper-plane"></i></a></div>
	  <div class="nav-box"> <a href="add.php"><h3>Send</h3><i class="fa fa-thumb-tack"></i></a></div>
	  <div class="nav-box"> <a href="accounts.php"><h3>Email accounts</h3><i class="fa fa-list"></i></a></div>
	  <div class="nav-box"> <a href="labelNames.php"><h3>Email labels</h3><i class="fa fa-list"></i></a></div>
	  <div class="nav-box"> <a href="settings.php"><h3>Settings</h3><i class="fa fa-cogs"></i></a></div>
	  <div class="nav-box"> <a href="/logs/emails.log"><h3>Log</h3><i class="fa fa-file-o"></i></a></div>
	  <div class="nav-box"> <a href="browser.php"><h3>Browse attachments</h3><i class="fa fa-folder"></i></a></div>
	  
	  <div class="nav-box"> <a href="import.php"><h3>Put on the box</h3><i class="fa fa-cloud-upload"></i></a></div>
	  <div class="nav-box"> <a href="export.php"><h3>Take off the box</h3><i class="fa fa-cloud-download "></i></a></div>
	  <div class="nav-box"> <a href="help/index.php" ><h3>Learn</h3><i class="fa fa-graduation-cap"></i></a></div>
	</div>
	<div id="snackbar" ></div>
</section>



<?php 
 include $webUIRoot .  "footer.php";
?>
