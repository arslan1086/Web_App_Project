<?php

include $_SERVER['DOCUMENT_ROOT'] . "/header.php";
include $_SERVER["DOCUMENT_ROOT"] . "/htmlHeader.php";
include $_SERVER['DOCUMENT_ROOT'] . "/navBar.php";

?>

<section class="landing">

	<div class="titleHeader">
		<i class="fa fa-music"></i> Music and sounds
	</div>

	<div class="nav-boxes">
		<div class="nav-box"> <a href="search.php"  ><h3>Search</h3><i class="fa fa-search"></i></a></div>
		<div class="nav-box"> <a href="browse.php" ><h3>Browse</h3><i class="fa fa-folder-open"></i></a></div>
		<div class="nav-box"> <a href="wishlist.php" ><h3>Wish list</h3><i class="fa fa-heart-o"></i></a></div>
		<div class="nav-box"> <a href="playlists.php" ><h3>Playlists</h3><i class="fa fa-list-ul"></i></a></div>

		<div class="nav-box"> <a href="rip.php"><h3>Rip a CD</h3><i class="fa fa-bullseye"></i></a></div>
		<div class="nav-box"> <a href="upload.php"  ><h3>Upload album</h3><i class="fa fa-upload"></i></a></div>
		<div class="nav-box"> <a href="export.php" ><h3>Export Music</h3><i class="fa fa-download"></i></a></div>
		<div class="nav-box"> <a href="help/index.php"  ><h3>Learn</h3><i class="fa fa-mortar-board"></i></a></div>
	</div>

</section>

<!-- <script src="/apps/apps.js" ></script> -->

<?php
  include $_SERVER['DOCUMENT_ROOT'] . "/footer.php";
?>
