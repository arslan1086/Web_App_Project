<?php
	//nothing much to say here!
?>

<body>

   <div class="grid-wrapper">

	<nav>
		<!-- accessibility, per lighthouse audit, this helps screen readers -->
		<a class="skip-link hidden" href="#main">Skip to main</a>

		<!-- logo + buttons + search box in that order, to display well on phone screen -->

		<!--  display search box and button on the next line on a phone, but not on index page -->
		<a href="/index.php" id="brainbox-logo" class="arrowNavElement" >Brainbox</a>
		<!-- nb open-nav-menu etc is used by js to open modal, event listener for this class to capture touch to either element, id is for styling, needs indiv-->
		<span id="open-nav-notif" class="open-nav-notif arrowNavElement"  ><i class="fa fa-bell open-nav-notif" style="cursor:pointer" ></i></span>

		<span id="open-nav-menu" class="open-nav-menu arrowNavElement" ><i class="fa fa-bars open-nav-menu" id="menu-icon" ></i>  MENU </span>

		<span id="connection-status" class="arrowNavElement"></span>

		<!-- modal container for nav and notifs  -->
		<div id="modal-nav-container"></div>
		
	</nav>
<!-- nb js for this section is called in the html header include file  /htmlHeader.php -->
<!-- we don't close the body elem here, this is just the beginning ... -->
