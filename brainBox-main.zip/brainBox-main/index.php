<?php
/*
	* UI page for questions input , navigation and some help
*/

include $_SERVER["DOCUMENT_ROOT"] . '/htmlHeader.php';
include $_SERVER["DOCUMENT_ROOT"] . '/navBar.php';

//get the brain svg into html code, so we can use js to change its colour
//$brain =  file_get_contents( $_SERVER['DOCUMENT_ROOT'] . '/images/lips.svg' );

?>

<!--   content section, only one for index page LEFT w3-center for now, don't know how to center divs without it WILL BE SORTED WITH GRID -->
<main class="top-section bb-center">



	<section id="main" style="margin-top:70px"  >

		<section id="speak-question" class="brain-icon-container arrowNavElement hidden" >
			<!-- <img id="lips" class="arrowNavElement" src="/images/kiss.png"  > -->
			<svg id="lips" class="shadow"> <?= $brain ?></svg>
			<p>Click the icon and ask away</p>
			<button id="help-btn" class="colour4 textcolour5 arrowNavElement" style="width:50%;padding:10px" >What can I ask?</button>
		</section>

		<section id="write-question" class="" >
			<!-- nb id attribute must precede class attrib, as class css needs to override id css in navigation.js -->	
			<input id="search-brainbox" class="arrowNavElement" placeholder="type a question ..." />
			<i id="search-bbx-btn" class="fa fa-search arrowNavElement " ></i>

			<!-- the submit btn is outside the form html 
			<button type="button" id="searchButton" class="arrowNavElement"  >Search BrainBox</button> -->
		</section>

		<button id="switch" >Want to speak instead?</button>

		<!-- chat window -->
		<div id="chat-window" ></div>
		<!-- snackbar -->
		<div id="snackbar" ></div>
		<!-- speak modal -->
		<div id="speak-modal"></div>
		<!-- HELP Modal -->
		<div id="help-modal"></div>

	</section>


</main>

<script src="/lib/js/hs/index.js" ></script>
