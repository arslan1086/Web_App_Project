<!DOCTYPE html>
<html lang="en" >
<head>
	<title>Brainbox</title>

	<!--
		these headers are nec. seems independent of  Apache web server. The page will load ok, but
		the browser will complain in the console 
	-->
	<meta content="utf-8" http-equiv="encoding">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1"/>
	<!-- PWA req, matches the manifest.json -->
	<meta name="theme-color" content="#448D76" />
	<meta name="description" content="Brainbox is made by Datakey.io, it is your all in one
	cloud, smart device controller, an media streamer.">

	<!--css stylesheets -->
	<!-- <link rel="stylesheet" href="/lib/css/w3.css" type="text/css"/>  
	let us try to remove the w3.css sheet, most of what I need is now in homeServer.css -->
	<link rel="stylesheet" href="/lib/css/hs/homeServer.css" type="text/css" media="screen,print"/>
	<link rel="stylesheet" href="/lib/css/hs/navbar.css" type="text/css" media="screen,print" />
	<link rel="stylesheet" href="/lib/css/font-awesome.min.css" type="text/css" />

	<!-- manifest links for web apps are created by index.js not here -->

	<!-- iOS support for web apps -->
	<link rel="apple-touch-icon" href="/images/box-114.png" />
	<meta name="apple-mobile-web-app-status-bar" content="#448D76" />

	<!-- main js for all pages -->
	<script type="text/javascript" src="/lib/js/hs/homeServer.js" ></script>
	<script type="text/javascript" src="/lib/js/hs/navbar.js" ></script>
	<script type="text/javascript" src="/lib/js/hs/navigation.js" ></script>

	<!-- browser icon, added png, as FF doesn't seem to like .ico much, 
	it needs the /, else it will look for a path relative to its own dir-->
	<link type="image/x-icon" href="/favicon.ico"  rel="shortcut icon"  >
	<link type="image/x-icon" href="/favicon.png"  rel="shortcut icon"  >

</head>

<body>

   <div class="grid-wrapper">

	<nav>
		<!-- accessibility, per lighthouse audit, this helps screen readers -->
		<a class="skip-link hidden" href="#main">Skip to main</a>

		<!-- logo + buttons + search box in that order, to display well on phone screen -->

		<!--  display search box and button on the next line on a phone, but not on index page -->
		<a href="/index.php" id="brainbox-logo" class="arrowNavElement" >Brainbox</a>
		<!-- nb open-nav-menu etc is used by js to open modal, event listener for this class to capture touch to either element, id is for styling, needs indiv-->
		<span id="open-nav-notif" class="open-nav-notif arrowNavElement"  ><i class="fa fa-bell open-nav-notif" style="cursor:pointer" ></i></span>

		<span id="open-nav-menu" class="open-nav-menu arrowNavElement" ><i class="fa fa-bars open-nav-menu" id="menu-icon" ></i>  MENU </span>

		<span id="connection-status" class="arrowNavElement"></span>

		<!-- modal container for nav and notifs  -->
		<div id="modal-nav-container"></div>
		
	</nav>
<!-- nb js for this section is called in the html header include file  /htmlHeader.php -->
<!-- we don't close the body elem here, this is just the beginning ... -->
<div class="app-boxes">
	<div class="app-box">
		<h3>SqueezeBox</h3>
		<a href="/apps/squeezebox/" >
		<i class="fa fa-music" style="color:#ff33cc"></i>
		</a>
	</div>
	<div class="app-box">
		<h3>inBox</h3>
		<a href="/apps/inBox/" >
		<i class="fa fa-paper-plane-o" style="color:#3399ff"></i>
		</a>
	</div>
	<div class="app-box">
		<h3>Movies</h3>
		<a href="/apps/movies/" >
		<i class="fa fa-film" style="color:#0c7bf1"></i>
		</a>
	</div>
	<div class="app-box">
		<h3>Passwords</h3>
		<a href="/apps/passwords/" >
		<i class="fa fa-key" style="color:#b56f30"></i>
		</a>
	</div>
	<div class="app-box">
		<h3>People</h3>
		<a href="/apps/people/" >
		<i class="fa fa-address-card" style="color:#8598b5"></i>
		</a>
	</div>
	<div class="app-box">
		<h3>Bookmarks</h3>
		<a href="/apps/bookmarks/" >
		<i class="fa fa-bookmark-o" style="color:#3366ff"></i>
		</a>
	</div>
	<div class="app-box">
		<h3>Lists</h3>
		<a href="/apps/lists/" >
		<i class="fa fa-list" style="color:#c4512d"></i>
		</a>
	</div>
	<div class="app-box">
		<h3>Notes</h3>
		<a href="/apps/notes/" >
		<i class="fa fa-paperclip" style="color:#9df221"></i>
		</a>
	</div>
	<div class="app-box">
		<h3>PhoneBox</h3>
		<a href="/apps/phoneBox/" >
		<i class="fa fa-phone" style="color:#ec1461"></i>
		</a>
	</div>
	<div class="app-box">
		<h3>BookBox</h3>
		<a href="/apps/bookBox/" >
		<i class="fa fa-book" style="color:#161d5f"></i>
		</a>
	</div>
	<div class="app-box">
		<h3>Groceries</h3>
		<a href="/apps/groceries/" >
		<i class="fa fa-shopping-cart" style="color:#2ce81c"></i>
		</a>
	</div>
	<div class="app-box">
		<h3>Gogglebox</h3>
		<a href="/apps/gogglebox/" >
		<i class="fa fa-television" style="color:#8598b5"></i>
		</a>
	</div>
	<div class="app-box">
		<h3>Calendar</h3>
		<a href="/apps/calendar/" >
		<i class="fa fa-calendar" style="color:#FFCC66"></i>
		</a>
	</div>
	<div class="app-box">
		<h3>Radio</h3>
		<a href="/apps/radio/" >
		<i class="fa fa-podcast" style="color:#8598b5"></i>
		</a>
	</div>
	<div class="app-box">
		<h3>MoneyBox</h3>
		<a href="/apps/homebooks/" >
		<i class="fa fa-calculator" style="color:#aabf62"></i>
		</a>
	</div>
	<div class="app-box">
		<h3>Lunchbox</h3>
		<a href="/apps/lunchbox/" >
		<i class="fa fa-cutlery" style="color:#20fe51"></i>
		</a>
	</div>
	<div class="app-box">
		<h3>homeVideos</h3>
		<a href="/apps/homeVideos/" >
		<i class="fa fa-video-camera" style="color:#a1eb3a"></i>
		</a>
	</div>
	<div class="app-box">
		<h3>Office</h3>
		<a href="/apps/office/" >
		<i class="fa fa-file-o" style="color:#b9218b"></i>
		</a>
	</div>
	<div class="app-box">
		<h3>Audio</h3>
		<a href="/apps/audio/" >
		<i class="fa fa-headphones" style="color:#ce219a"></i>
		</a>
	</div>
	<div class="app-box">
		<h3>Growbox</h3>
		<a href="/apps/growbox/" >
		<i class="fa fa-leaf" style="color:green"></i>
		</a>
	</div>
	<div class="app-box">
		<h3>Health</h3>
		<a href="/apps/health/" >
		<i class="fa fa-heartbeat" style="color:#e0ead1"></i>
		</a>
	</div>
	<div class="app-box">
		<h3>Pets</h3>
		<a href="/apps/pets/" >
		<i class="fa fa-paw" style="color:#33a592"></i>
		</a>
	</div>
	<div class="app-box">
		<h3>Vehicles</h3>
		<a href="/apps/vehicles/" >
		<i class="fa fa-car" style="color:#935adc"></i>
		</a>
	</div>
	<div class="app-box">
		<h3>Timers</h3>
		<a href="/apps/timers/" >
		<i class="fa fa-clock-o" style="color:#e56661"></i>
		</a>
	</div>
	<div class="app-box">
		<h3>Photos</h3>
		<a href="/apps/photos/" >
		<i class="fa fa-camera" style="color:#d7f6f4"></i>
		</a>
	</div>
	<div class="app-box">
		<h3>Inventory</h3>
		<a href="/apps/inventory/" >
		<i class="fa fa-umbrella" style="color:#f4e61a"></i>
		</a>
	</div>
	<div class="app-box">
		<h3>Websites</h3>
		<a href="/apps/websiteMaker/" >
		<i class="fa fa-globe" style="color:#90f0eb"></i>
		</a>
	</div>
	<div class="app-box">
		<h3>Properties</h3>
		<a href="/apps/properties/" >
		<i class="fa fa-home" style="color:#aabf62"></i>
		</a>
	</div>
	<div class="app-box">
		<h3>Assistive</h3>
		<a href="/apps/assistive/" >
		<i class="fa fa-wheelchair-alt" style="color:#ff1a1a"></i>
		</a>
	</div>
	<div class="app-box">
		<h3>Appliances</h3>
		<a href="/apps/appliances/" >
		<i class="fa fa-plug" style="color:#5351eb"></i>
		</a>
	</div>
	<div class="app-box">
		<h3>Water</h3>
		<a href="/apps/water/" >
		<i class="fa fa-tint" style="color:blue"></i>
		</a>
	</div>
	<div class="app-box">
		<h3>Investments</h3>
		<a href="/apps/investments/" >
		<i class="fa fa-line-chart" style="color:#991f00"></i>
		</a>
	</div>
	<div class="app-box">
		<h3>News</h3>
		<a href="/apps/news/" >
		<i class="fa fa-info-circle" style="color:#000044"></i>
		</a>
	</div>
	<div class="app-box">
		<h3>Banking</h3>
		<a href="/apps/banking/" >
		<i class="fa fa-bank" style="color:#ff704d"></i>
		</a>
	</div>
	<div class="app-box">
		<h3>Savings</h3>
		<a href="/apps/savings/" >
		<i class="fa fa-gbp" style="color:#10f60a"></i>
		</a>
	</div>
	<div class="app-box">
		<h3>Gas</h3>
		<a href="/apps/gas/" >
		<i class="fa fa-fire" style="color:orange"></i>
		</a>
	</div>
	<div class="app-box">
		<h3>SoapBox</h3>
		<a href="/apps/soapbox/" >
		<i class="fa fa-bullhorn" style="color:#e5e753"></i>
		</a>
	</div>
	<div class="app-box">
		<h3>PostBox</h3>
		<a href="/apps/postbox/" >
		<i class="fa fa-envelope-o" style="color:indigo"></i>
		</a>
	</div>
	<div class="app-box">
		<h3>House</h3>
		<a href="/apps/house/" >
		<i class="fa fa-home" style="color:#c4512d"></i>
		</a>
	</div>
	<div class="app-box">
		<h3>homeCare</h3>
		<a href="/apps/homeCare/" >
		<i class="fa fa-heart-o" style="color:pink"></i>
		</a>
	</div>
	<div class="app-box">
		<h3>zoom</h3>
		<a href="/apps/zoom/" >
		<i class="fa fa-fighter-jet" style="color:green"></i>
		</a>
	</div>
	<div class="app-box">
		<h3>Lighting</h3>
		<a href="/apps/lightbox/" >
		<i class="fa fa-lightbulb-o" style="color:#ffff33"></i>
		</a>
	</div>
	<div class="app-box">
		<h3>Electric</h3>
		<a href="/apps/electric/" >
		<i class="fa fa-plug" style="color:#d53000"></i>
		</a>
	</div>
	<div class="app-box">
		<h3>HomeLock</h3>
		<a href="/apps/homelock/" >
		<i class="fa fa-lock" style="color:#33cc33"></i>
		</a>
	</div>
	<div class="app-box">
		<h3>Warmbox</h3>
		<a href="/apps/warmbox/" >
		<i class="fa fa-thermometer-3" style="color:#ff9900"></i>
		</a>
	</div>
	<div class="app-box">
		<h3>heatingOil</h3>
		<a href="/apps/heatingOil/" >
		<i class="fa fa-fire" style="color:#71affd"></i>
		</a>
	</div>
	<div class="app-box">
		<h3>Doorbell</h3>
		<a href="/apps/intercom/" >
		<i class="fa fa-bell" style="color:olive"></i>
		</a>
	</div></div>     <footer>
        <!-- rich text editor -->
        <script src="/lib/js/nicEdit.js"></script>
  	   <div> 
          Suggestion Box ... How could we improve this page? 
          <button id="improve-page-btn" class="arrowNavElement" >Tell us</button>
        </div>

     </footer>
   <!-- end whole page container id=grid-wrapper-->
   </div>
</body>
</html>