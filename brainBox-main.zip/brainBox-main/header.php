<?php

/*
	header for static page for tv nav dev

*/
#session_start();
#session_regenerate_id(); // keep session data, but create new id for data

#redirect if user has not changed default password
#if( $_SESSION['adminPassword'] ):
#	header( "Location: /auth/password-warning.php");
#	exit;
#endif;

//get the config var from ini file FIXEME write this to $_SESSION once after sign in success /lib/php/epFunctions
#$PATH = '/etc/brainbox/brainbox.ini';
#$ini = parse_ini_file($PATH);
//nb leave this, because it is assumed by all scripts
#foreach($ini as $key => $val):
#	$$key = $val;  //make the key the var name ie $ini[foo] = var becomes $foo = bar
#endforeach;
 
//if first time user redirect  to setup 
#if( $FIRST_TIME == true ): 
#	header("Location: /setup/setUp-1.php");
#	exit;
#endif;

//for development try to force browser to reload css and js each time
header("Cache-Control: no-store"); //The assets are downloaded every time // or "no-cache"
header("Pragma: no-cache"); // legacy header
header("Server: Brainbox Microserver");
