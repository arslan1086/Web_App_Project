<!DOCTYPE html>
<html lang="en" >
<head>
	<title>Brainbox</title>

	<!--
		these headers are nec. seems independent of  Apache web server. The page will load ok, but
		the browser will complain in the console 
	-->
	<meta content="utf-8" http-equiv="encoding">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1"/>
	<!-- PWA req, matches the manifest.json -->
	<meta name="theme-color" content="#448D76" />
	<meta name="description" content="Brainbox is made by Datakey.io, it is your all in one
	cloud, smart device controller, an media streamer.">

	<!--css stylesheets -->
	<!-- <link rel="stylesheet" href="/lib/css/w3.css" type="text/css"/>  
	let us try to remove the w3.css sheet, most of what I need is now in homeServer.css -->
	<link rel="stylesheet" href="/lib/css/hs/homeServer.css" type="text/css" media="screen,print"/>
	<link rel="stylesheet" href="/lib/css/hs/navbar.css" type="text/css" media="screen,print" />
	<link rel="stylesheet" href="/lib/css/font-awesome.min.css" type="text/css" />

	<!-- manifest links for web apps are created by index.js not here -->

	<!-- iOS support for web apps -->
	<link rel="apple-touch-icon" href="/images/box-114.png" />
	<meta name="apple-mobile-web-app-status-bar" content="#448D76" />

	<!-- main js for all pages -->
	<script type="text/javascript" src="/lib/js/hs/homeServer.js" ></script>
	<script type="text/javascript" src="/lib/js/hs/navbar.js" ></script>
	<script type="text/javascript" src="/lib/js/hs/navigation.js" ></script>

	<!-- browser icon, added png, as FF doesn't seem to like .ico much, 
	it needs the /, else it will look for a path relative to its own dir-->
	<link type="image/x-icon" href="/favicon.ico"  rel="shortcut icon"  >
	<link type="image/x-icon" href="/favicon.png"  rel="shortcut icon"  >

</head>
